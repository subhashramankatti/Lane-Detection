# Lane-Detection
To Run this code, please follow this steps:
1. Clone the repository.
2. Download any DashCam video you want - I highly reccomand to write "DashCam Tour 4K" in youtube.
3. Make sure you saved the video and the Mobileye.py at the same folder.
4. At line 206 replace the "videoName.mp4" with the vidoe name and the video type you downloaded.
5. Hit Run
.
.
.
Enjoy!
